

    <!--  Header Part Start  -->
    @include('Layouts.header')
    <!--  Header Part End  -->
    @include('Layouts.navbar')

<div class="collapse navbar-collapse" id="nav_list">
          <ul class="nav navbar-nav navbar-right">
            <li ><a href="/">Home</a></li>
            <li ><a href="shoppers">For Shoppers</a></li>
            <li class="active"><a href="retailer">For Retailers</a></li>
            <li><a href="aboutus">About Us</a></li>
          </ul>
        </div>
        <!-- /.navbar-collapse -->
      </div>
    </div>
    <!-- /.container -->
  </nav>
</header>
    <!--  Banner Part Start  -->
    <section id="banner_part">
      <div class="slide_active">
        <div class="banner_item" data-bg-image="images/HomePageHeroBanner.png">
          <div class="container text-center">
            <div class="row">
              <div class="banner_text">
                <h3>We  transform </h3>
                <h4><span>the  way  businesses</span>  <h3>interact with</h3>  <h4><span>consumers</span></h4></h4>
                <p>
                  Lorem ipsum dolor sit amet, consectetur adipisicing elit. Amet
                  porro eaque assumenda consequatur asperiores laboriosam
                  debitis, explicabo.
                </p>
                <h5>Download our for free</h5>
                <button type="button"><img src="./images/AppStoreDownloadButton.png" alt="" class="DownloadBtn AppStore"></button>
                <button type="button"><img src="./images/PlayStoreDownloadButton.png" alt="" class="DownloadBtn img-responsive"></button>
              </div>
            </div>
          </div>
        </div>
        
     
    </section>
    <!--  Banner Part End  -->

    <!--  About Part Start  -->
    <section id="about_part">
      <div class="container">
        <div class="WhiteContainer row">
          <div class="col-sm-6 visible-xs">
            <div class="about_right section_head">
              <h2><span>About </span>Kenaf</h2>
              <p>
                We love building and rebuilding brands through our specific
                skills. Using colour, fonts, and illustration, we brand
                companies in a way they will never forget.We love building and
                rebuilding brands through our specific skills. Using colour,
                fonts, and illustration, we brand companies in a way they will
                never forget...
              </p>
              
            </div>
          </div>
          <div class="col-sm-6">
            <div class="about_left text-center">
              <div class="about_left_inner">
                
              <img src="images/ForRetailers.png" alt="" >
               
              </div>
            </div>
          </div>
          <div class="col-sm-6 hidden-xs">
            <div class="about_right section_head">
              <h2><span>About </span>Kenaf</h2>
              <p>
                  Lorem ipsum, dolor sit amet consectetur adipisicing elit. Dolor, dicta assumenda nulla aperiam laborum debitis tempore dolore aut atque perferendis voluptas magni fuga tempora unde ratione ipsum eveniet rem reprehenderit iure nisi, quo nihil ipsa fugiat et? Odit neque odio sunt mollitia enim explicabo hic autem molestiae sapiente soluta eligendi veritatis nisi tenetur similique ab earum voluptatibus aut qui at, unde atque aliquam nesciunt nemo quisquam. Fuga corrupti atque ex suscipit, sapiente quidem culpa ducimus quasi, eveniet, quisquam necessitatibus praesentium. Exercitationem voluptas incidunt nam, facilis accusamus omnis doloribus vero culpa rerum aspernatur! Dolor fugit dolore hic reprehenderit neque laboriosam qui.
              </p>
              
            </div>
          </div>
        </div>
      </div>
    </section>


     <!-- columns -->

    
    






   

    <!-- HowItWorks -->
    <section id="about_part_HowItWorks">
      <div class="container">
        
        <div class="service_bottom text-center">
                    <div class="col-md-4 col-sm-6 col-xs-12">
                        
                            <img src="images/servisShopper1.png" alt="" >
                            <!-- <a href="#"><h3>Web Design</h3></a>
                            <p>Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim.</p>
                            <a href="#" class="ser_btn">Read More <i class="fa fa-arrow-right"></i></a> -->
                        
                    </div>
                    <div class="col-md-4 col-sm-6 col-xs-12">
                    <img src="images/servisShopper2.png" alt="" >
                    </div>
                    <div class="col-md-4 col-sm-6 col-xs-12">
                    <img src="images/servisShopper3.png" alt="" >
                    </div>
                </div>
        
      </div>
    </section>
     <!-- For Shoppers -->
    
     @include('Layouts.footer')
