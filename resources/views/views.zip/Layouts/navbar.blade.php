
<header id="header_part">
      <nav class="navbar navbar-default my_nav">
        <div class="container">
          <!-- Brand and toggle get grouped for better mobile display -->
          <div class="row">
            <div class="navbar-header">
              <button
                type="button"
                class="navbar-toggle collapsed"
                data-toggle="collapse"
                data-target="#nav_list"
                aria-expanded="false"
              >
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
              <a class="main_logo" href="index-2.html">
                <img src="images/KenafNavbarLogopng.png" alt="LOGO" />
              </a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
           