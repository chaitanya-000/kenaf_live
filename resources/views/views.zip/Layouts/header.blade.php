<!DOCTYPE html>
<html lang="en">
  <!-- Mirrored from techincent.com/demo/spirit/ by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 13 Dec 2022 18:10:11 GMT -->
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="author" content="ProTheme Lab" />
    <meta name="description" content="Corporate Business Landing template" />
    <meta
      name="keywords"
      content="web template, business themes, landing page template, responsive, bootstrap, mobile, themeforest template, corporate marketing template, corporate business, business showcase, business porfolio"
    />

    <title>Spirit - Corporate Business Marketing Templates</title>

    <!-- Favicon -->
    <link rel="icon" href="images/favicon.ico" />

    <!--  Css Files  -->
    <link rel="stylesheet" href="css/bootstrap.min.css" />
    <link rel="stylesheet" href="css/animate.min.css" />
    <link rel="stylesheet" href="css/font-awesome.min.css" />
    <link rel="stylesheet" href="css/slick.css" />
    <link rel="stylesheet" href="css/venobox.css" />
    <link rel="stylesheet" href="css/style.css" />
    <link rel="stylesheet" href="css/responsive.css" />
  </head>

  <body>
    <!--  Pre-Loader Start -->
    <div id="preloader">
      <div class="pre_img">
        <img src="images/pre-loader.gif" alt="" />
      </div>
    </div>
    <!--  Pre-Loader End -->
