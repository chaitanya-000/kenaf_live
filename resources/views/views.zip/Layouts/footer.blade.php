<div class="Subscribe">
      <div class="Subscribe_container">
        <div class="Subscribe_container_TextContainer">
          <img src="./images/subscribeOurNewsLetterFontImage.png" alt="" class="Subscribe_container_TextContainer_FontImage">
          <div class="Subscribe_container_TextContainer_subtext">
            Lorem, ipsum dolor sit amet consectetur adipisicing elit. Vitae, ex.
          </div>
        </div>

        <div class="Subscribe_container_inputContainer">
          <img src="./images/MailOpenIcon.png" alt="" class="Subscribe_container_inputContainer_emailIcon">
          <input class="Subscribe_container_input" placeholder="Your email here">
          <button class="Subscribe_container_inputContainer_button">
            <img class="Subscribe_container_inputContainer_button_icon" src="./images/PaperPlaneIcon.png">Send
          </button>
        </div>
      </div>
    </div>
 
 <!--  footer Part Start  -->
 <footer class="footer">
      <div class="footer_container">
        <div class="footer_container_top">
          <img
            class="footer_container_top_logo"
            src="./images/FooterTopLogo.png"
          />
          <div class="footer_container_top_flex">
            <div class="footer_container_top_flex_heading">Kenaf</div>
            <div class="footer_container_top_flex_items">
              <div class="footer_container_top_flex_subtext">What We do</div>
              <div class="footer_container_top_flex_subtext">About us</div>
              <div class="footer_container_top_flex_subtext">Core values</div>
              <div class="footer_container_top_flex_subtext">Our team</div>
            </div>
          </div>
          <div class="footer_container_top_flex">
            <div class="footer_container_top_flex_heading">Shoopers</div>
            <div class="footer_container_top_flex_items">
              <div class="footer_container_top_flex_subtext">
                Kenaf for shoppers
              </div>
              <div class="footer_container_top_flex_subtext">Benefits</div>
              <div class="footer_container_top_flex_subtext">FAQ</div>
            </div>
          </div>
          <div class="footer_container_top_flex">
            <div class="footer_container_top_flex_heading">Retailers</div>
            <div class="footer_container_top_flex_items">
              <div class="footer_container_top_flex_subtext">
                Kenaf for Retailers
              </div>
              <div class="footer_container_top_flex_subtext">Benefits</div>
              <div class="footer_container_top_flex_subtext">
                Sign up for Demo
              </div>
            </div>
          </div>
          <div class="footer_container_top_flex">
            <div class="footer_container_top_flex_heading">Legal</div>
            <div class="footer_container_top_flex_items">
              <div class="footer_container_top_flex_subtext">
                Privacy Policy
              </div>
              <div class="footer_container_top_flex_subtext">
                Terms of Service
              </div>
            </div>
          </div>

          <div class="footer_container_top_flex_Download">
            <div class="footer_container_top_flex_heading">
              Download for free
            </div>
            <div class="footer_container_top_flex_Download_buttonContainer">
              <img
                src="./images/PlaystoreDownloadButton.png"
                class="footer_container_top_flex_downloadForFreeButtons"
              />
              <img
                src="./images/AppstoreDownloadButton.png"
                class="footer_container_top_flex_downloadForFreeButtons"
              />
            </div>
          </div>
        </div>
        <div class="footer_container_lineDivider"></div>
        <div class="footer_container_bottom"></div>
      </div>
    </footer>
    <!--  Footer Part End  -->

    <!--  Bact to Top button start -->
    <div id="backtotop">
      <i class="fa fa-arrow-up backtotop_btn"></i>
    </div>
    <!--  Bact to Top button End -->

    <script
      data-cfasync="false"
      src="../../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"
    ></script>
    <script src="js/jquery-1.12.4.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/imagesloaded.min.js"></script>
    <script src="js/jquery.counterup.min.js"></script>
    <script src="js/jquery.filterizr.min.js"></script>
    <script src="js/slick.min.js"></script>
    <script src="js/venobox.min.js"></script>
    <script src="js/waypoints.min.js"></script>
    <script src="js/script.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCm8veVh4ipYx0T0217Njyu1zPiwm60f3U&amp;callback=initMap"></script>
  </body>

  <!-- Mirrored from techincent.com/demo/spirit/ by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 13 Dec 2022 18:10:38 GMT -->
</html>